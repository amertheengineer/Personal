#ifndef READLINE_H_INCLUDED
#define READLINE_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int read_line(char str[], int n);



#endif // READLINE_H_INCLUDED
